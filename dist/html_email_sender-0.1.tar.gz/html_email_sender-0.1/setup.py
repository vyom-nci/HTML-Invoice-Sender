from setuptools import setup, find_packages

setup(
    name='html_email_sender',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'Jinja2',
    ],
)
