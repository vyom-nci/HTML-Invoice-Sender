# HTML Email Sender library

This library allows you to send emails to a recipient with HTML templates using Python.
